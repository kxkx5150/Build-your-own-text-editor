//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by resource.rc
//
#define IDR_MENU1                       101
#define IDI_ICON1                       102
#define IDR_ACCELERATOR1                103
#define IDD_OPTIONS1                    104
#define IDD_OPTIONS                     104
#define IDI_ICON2                       105
#define IDD_SPACING                     106
#define IDD_DIALOG1                     107
#define IDD_FONT                        107
#define IDD_DIALOG2                     108
#define IDD_FONTEXTRA                   112
#define IDD_DISPLAY                     113
#define IDD_ABOUT                       114
#define IDB_BITMAP1                     115
#define IDB_BITMAP2                     116
#define IDI_ICON3                       118
#define IDC_COMBO1                      1000
#define IDC_FONTLIST                    1000
#define IDC_COMBO2                      1001
#define IDC_SIZELIST                    1001
#define IDC_CHECK1                      1002
#define IDC_COMBO3                      1003
#define IDC_EDIT1                       1003
#define IDC_COMBO4                      1004
#define IDC_EDIT2                       1004
#define IDC_SPIN1                       1005
#define IDC_SPIN2                       1006
#define IDC_PREVIEW                     1009
#define IDC_LIST1                       1010
#define IDC_ITEMLIST                    1010
#define IDC_COMBO5                      1011
#define IDC_BUTTON1                     1012
#define IDC_BGCOLCOMBO                  1012
#define IDC_BUTTON2                     1014
#define IDC_CUSTBUT1                    1014
#define IDC_BUTTON3                     1015
#define IDC_DISPLAYITEMLIST             1015
#define IDC_CUSTBUT2                    1015
#define IDC_FGCOLCOMBO                  1016
#define IDC_DEFAULTS                    1017
#define IDC_BOLD                        1018
#define IDC_PADDINGA                    1019
#define IDC_PADDINGB                    1020
#define IDC_ADVANCED                    1021
#define IDC_CHECK2                      1022
#define IDC_CHECK3                      1023
#define IDC_ADDCONTEXT                  1023
#define IDC_CHECK4                      1024
#define IDC_REPLACENOTEPAD              1024
#define IDC_PROGRESS1                   1025
#define IDC_CHECK10                     1025
#define IDC_RADIO1                      1026
#define IDC_RADIO2                      1027
#define IDC_CHECK5                      1028
#define IDC_CHECK6                      1029
#define IDC_CHECK7                      1030
#define IDC_CHECK8                      1031
#define IDC_CHECK9                      1032
#define IDC_EDIT3                       1033
#define IDC_EDIT4                       1034
#define IDC_LONGLINELIM                 1034
#define IDC_BANNER                      1035
#define IDC_SPIN3                       1037
#define IDC_HEADER                      1038
#define IDC_HEADER2                     1039
#define IDC_LINENOSFIRST                1040
#define IDC_LINENOS                     1041
#define IDC_SELMARGIN                   1042
#define IDC_LONGLINEMODE                1043
#define IDC_SELMARGIN2                  1044
#define IDC_HIGHLIGHTCURLINE            1044
#define IDC_MEMWINPOS                   1044
#define IDC_MEMWINPOSFILE               1045
#define IDM_FILE_NEW                    40001
#define IDM_FILE_OPEN                   40002
#define IDM_FILE_EXIT                   40003
#define IDM_HELP_ABOUT                  40004
#define IDM_VIEW_FONT                   40005
#define IDM_VIEW_LINENUMBERS            40006
#define IDM_VIEW_LONGLINES              40007
#define IDM_VIEW_SAVENOW                40008
#define IDM_VIEW_SAVEEXIT               40009
#define IDM_FILE_PRINT                  40010
#define IDM_VIEW_ASCII                  40012
#define IDM_VIEW_UTF8                   40013
#define IDM_VIEW_UTF16                  40014
#define IDM_VIEW_UTF16BE                40015
#define IDM_EDIT_UNDO                   40016
#define IDM_EDIT_REDO                   40017
#define IDM_EDIT_CUT                    40018
#define IDM_EDIT_COPY                   40019
#define IDM_EDIT_PASTE                  40020
#define IDM_EDIT_DELETE                 40021
#define IDM_EDIT_SELECTALL              40022

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        119
#define _APS_NEXT_COMMAND_VALUE         40023
#define _APS_NEXT_CONTROL_VALUE         1046
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
