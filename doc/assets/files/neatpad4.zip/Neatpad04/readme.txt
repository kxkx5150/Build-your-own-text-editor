NEATPAD - a simple win32 text editor with full source

Visit www.catch22.net/tuts for more information

Written by J Brown 2005
Freeware
